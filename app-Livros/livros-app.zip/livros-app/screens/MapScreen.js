import React, { useEffect, useState } from 'react';
import MapView, { Marker } from 'react-native-maps';
import { View, ActivityIndicator } from 'react-native';

const API_URL = 'http://172.26.34.143:3000';

export default function MapScreen() {
  const [livros, setLivros] = useState([]);
  const [regiao, setRegiao] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const res = await fetch(`${API_URL}/livros`);
      const data = await res.json();
      setLivros(data);

      if (data.length > 0) {
        const avgLat = data.reduce((sum, b) => sum + Number(b.latitude), 0) / data.length;
        const avgLng = data.reduce((sum, b) => sum + Number(b.longitude), 0) / data.length;

        setRegiao({
          latitude: avgLat,
          longitude: avgLng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        });
      }
    };

    fetchData();
  }, []);

  if (!regiao) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <MapView style={{ flex: 1 }} initialRegion={regiao}>
        {livros.map((book) => (
          <Marker
            key={book._id}
            coordinate={{
              latitude: Number(book.latitude),
              longitude: Number(book.longitude),
            }}
            title={book.title}
            description={book.comment}
            pinColor="blue"
          />
        ))}
      </MapView>
    </View>
  );
}
