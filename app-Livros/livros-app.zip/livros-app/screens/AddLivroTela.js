import React, { useEffect, useState } from 'react';
import { View, Image, Alert } from 'react-native';
import { TextInput, Button } from 'react-native-paper';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from '../styles/styles';

const API_URL = 'http://172.26.34.143:3000';
const STORAGE_KEY = '@books';

export default function AddLivroTela({ navigation }) {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [comment, setComment] = useState('');
  const [image, setImage] = useState(null);
  const [location, setLocation] = useState(null);

  // Solicita permissão de localização
  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const loc = await Location.getCurrentPositionAsync({});
        setLocation(loc.coords);
      } else {
        Alert.alert('Permissão de localização negada');
      }
    })();
  }, []);

  // Escolhe imagem da galeria
  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permissão para acessar galeria negada!');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true,
      quality: 0.7,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      setImage(result.assets[0]);
    }
  };

  // Salva livro na API e AsyncStorage
  const handleSubmit = async () => {
    if (!title || !author || !location) {
      Alert.alert('Erro', 'Preencha título, autor e permita a localização');
      return;
    }

    const formData = new FormData();
    formData.append('title', title);
    formData.append('author', author);
    formData.append('comment', comment);
    formData.append('latitude', location.latitude.toString());
    formData.append('longitude', location.longitude.toString());

    if (image) {
      formData.append('cover', {
        uri: image.uri,
        name: 'cover.jpg',
        type: 'image/jpeg',
      });
    }

    try {
      const response = await fetch(`${API_URL}/books`, {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (!response.ok) {
        throw new Error(`Erro HTTP: ${response.status}`);
      }

      const newBook = await response.json();

      // Atualiza AsyncStorage
      const storedData = await AsyncStorage.getItem(STORAGE_KEY);
      const books = storedData ? JSON.parse(storedData) : [];
      books.push(newBook);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(books));

      Alert.alert('Sucesso', 'Livro salvo!');
      navigation.goBack();
    } catch (error) {
      Alert.alert('Erro ao salvar livro', error.message);
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        label="Título"
        value={title}
        onChangeText={setTitle}
        style={styles.input}
        mode="outlined"
      />
      <TextInput
        label="Autor"
        value={author}
        onChangeText={setAuthor}
        style={styles.input}
        mode="outlined"
      />
      <TextInput
        label="Comentários"
        value={comment}
        onChangeText={setComment}
        style={styles.input}
        mode="outlined"
        multiline
      />
      <Button
        mode="outlined"
        icon="image"
        onPress={pickImage}
        style={styles.input}
      >
        Escolher Imagem
      </Button>
      {image && (
        <Image
          source={{ uri: image.uri }}
          style={{ width: '100%', height: 200, marginBottom: 10, borderRadius: 8 }}
        />
      )}
      <Button mode="contained" onPress={handleSubmit}>
        Salvar Livro
      </Button>
    </View>
  );
}