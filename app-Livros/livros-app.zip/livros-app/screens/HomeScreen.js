import React, { useEffect, useState } from 'react';
import { View, FlatList } from 'react-native';
import { Card, Title, Paragraph, FAB } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from '../styles/styles';

const API_URL = 'http://172.26.34.143:3000';
const STORAGE_KEY = '@books';

export default function HomeScreen({ navigation }) {
  const [books, setBooks] = useState([]);

  const fetchData = async () => {
    try {
      // Busca livros da API
      const res = await fetch(`${API_URL}/books`);
      if (!res.ok) throw new Error(`Erro HTTP: ${res.status}`);
      const data = await res.json();
      setBooks(data);
      // Salva no AsyncStorage
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Erro ao buscar livros:', error);
      // Carrega do AsyncStorage em caso de erro
      const cached = await AsyncStorage.getItem(STORAGE_KEY);
      if (cached) setBooks(JSON.parse(cached));
    }
  };

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', fetchData);
    return unsubscribe;
  }, [navigation]);

  return (
    <View style={styles.container}>
      <FlatList
        data={books}
        keyExtractor={(item) => item._id.toString()}
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <Card.Content>
              <Title>{item.title}</Title>
              <Paragraph>Autor: {item.author}</Paragraph>
              <Paragraph>Comentários: {item.comment}</Paragraph>
            </Card.Content>
            {item.cover && (
              <Card.Cover
                source={{ uri: `${API_URL}/${item.cover}` }}
                style={styles.image}
              />
            )}
          </Card>
        )}
      />
      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => navigation.navigate('Adicionar Livro')}
      />
    </View>
  );
}