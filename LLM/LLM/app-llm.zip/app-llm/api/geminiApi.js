export const fetchGeminiResponse = async (prompt) => {
  try {
    const response = await fetch('http://192.168.0.11/api/gemini', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ prompt }),
    });
    if (!response.ok) {
      throw new Error('Erro ao consultar o Gemini');
    }
    const data = await response.json();
    return data.geminiResponse;
  } catch (error) {
    console.error(error);
    throw error;
  }
}