import React, { useState } from 'react';
import { View, TextInput, Button } from 'react-native';
import styles from '../styles/PromptInputStyles';

const PromptInput = ({ onSubmit }) => {
  const [prompt, setPrompt] = useState('');

  const handlePress = () => {
    if (prompt) {
      onSubmit(prompt);
      setPrompt('');
    } else {
      alert('Por favor, insira um título de livro ou trecho.');
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Digite o título do livro ou trecho"
        value={prompt}
        onChangeText={setPrompt}
        multiline
      />
      <Button title="Enviar" onPress={handlePress} />
    </View>
  );
};

export default PromptInput;