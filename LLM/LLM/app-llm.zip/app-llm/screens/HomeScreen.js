import React from 'react';
import { View, Text } from 'react-native';
import PromptInput from '../components/PromptInput';
import { fetchGeminiResponse } from '../api/geminiApi';
import styles from '../styles/HomeScreenStyles';

const HomeScreen = ({ navigation }) => {
  const handlePromptSubmit = async (prompt) => {
    try {
      const geminiResponse = await fetchGeminiResponse(prompt);
      navigation.navigate('Result', { geminiResponse });
    } catch (error) {
      alert('Erro ao consultar o Gemini: ' + error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Consulta de Livros</Text>
      <Text style={styles.subtitle}>Digite o título de um livro ou trecho (ex.: "Pride and Prejudice")</Text>
      <PromptInput onSubmit={handlePromptSubmit} />
    </View>
  );
};

export default HomeScreen;