import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import styles from '../styles/ResultScreenStyles';

const ResultScreen = ({ route }) => {
  const { geminiResponse } = route.params;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Resposta do Gemini:</Text>
      <Text style={styles.content}>{geminiResponse}</Text>
    </ScrollView>
  );
};

export default ResultScreen;